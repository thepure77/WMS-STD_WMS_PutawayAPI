﻿using Comone.Utils;
using DataAccess;
using GIBusiness.GoodIssue;
using GIBusiness.Marshall;
using GIBusiness.Round;
using GIBusiness.Route;
using GIBusiness.RunWave;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Reflection;
using System.Text;

namespace GIBusiness.RunWaveService
{
    public class RunWaveService
    {
        public List<RunWaveDocViewModel> Filter()
        {
            try
            {
                using (var context = new GIDbContext())
                {

                    var queryResult = context.IM_PlanGoodsIssue.FromSql("sp_GetPlanGoodsIssue").Where(c => c.Document_Status != -1).OrderByDescending(o => o.Create_Date).ThenByDescending(n => n.PlanGoodsIssue_No).ToList();

                    var result = new List<RunWaveDocViewModel>();
                    foreach (var item in queryResult)
                    {
                        var resultItem = new RunWaveDocViewModel();

                        resultItem.PlanGoodsIssueIndex = item.PlanGoodsIssue_Index;
                        resultItem.OwnerIndex = item.Owner_Index;
                        resultItem.OwnerId = item.Owner_Id;
                        resultItem.OwnerName = item.Owner_Name;
                        resultItem.SoldToIndex = item.SoldTo_Index;
                        resultItem.SoldToName = item.SoldTo_Name;
                        resultItem.SoldToAddress = item.SoldTo_Address;
                        resultItem.ShipToIndex = item.ShipTo_Index;
                        resultItem.ShipToId = item.ShipTo_Id;
                        resultItem.ShipToName = item.ShipTo_Name;
                        resultItem.ShipToAddress = item.ShipTo_Address;
                        resultItem.DocumentTypeIndex = item.DocumentType_Index;
                        resultItem.DocumentTypeId = item.DocumentType_Id;
                        resultItem.DocumentTypeName = item.DocumentType_Name;
                        resultItem.PlanGoodsIssueNo = item.PlanGoodsIssue_No;
                        resultItem.PlanGoodsIssueDate = item.PlanGoodsIssue_Date.toString();
                        resultItem.PlanGoodsIssueDueDate = item.PlanGoodsIssue_Due_Date.toString();
                        resultItem.DocumentRefNo1 = item.DocumentRef_No1;
                        resultItem.DocumentRefNo2 = item.DocumentRef_No2;
                        resultItem.DocumentRefNo3 = item.DocumentRef_No3;
                        resultItem.DocumentRefNo4 = item.DocumentRef_No4;
                        resultItem.DocumentRefNo5 = item.DocumentRef_No5;
                        resultItem.DocumentStatus = item.Document_Status;
                        resultItem.UDF1 = item.UDF_1;
                        resultItem.UDF2 = item.UDF_2;
                        resultItem.UDF3 = item.UDF_3;
                        resultItem.UDF4 = item.UDF_4;
                        resultItem.UDF5 = item.UDF_5;
                        resultItem.DocumentPriorityStatus = item.DocumentPriority_Status;
                        resultItem.WarehouseIndex = item.Warehouse_Index;
                        resultItem.WarehouseId = item.Warehouse_Id;
                        resultItem.WarehouseName = item.Warehouse_Name;
                        resultItem.WarehouseIndexTo = item.Warehouse_Index_To;
                        resultItem.WarehouseIdTo = item.Warehouse_Id_To;
                        resultItem.WarehouseNameTo = item.Warehouse_Name_To;
                        resultItem.SoldToSubDistrictIndex = item.SoldTo_SubDistrict_Index;
                        resultItem.SoldToDistrictIndex = item.SoldTo_District_Index;
                        resultItem.SoldToProvinceIndex = item.SoldTo_Province_Index;
                        resultItem.SoldToCountryIndex = item.SoldTo_Country_Index;
                        resultItem.SoldToPostcodeIndex = item.SoldTo_Postcode_Index;
                        resultItem.SubDistrictIndex = item.SubDistrict_Index;
                        resultItem.DistrictIndex = item.District_Index;
                        resultItem.ProvinceIndex = item.Province_Index;
                        resultItem.CountryIndex = item.Country_Index;
                        resultItem.PostcodeIndex = item.Postcode_Index;
                        resultItem.CreateBy = item.Create_By;
                        resultItem.CreateDate = item.Create_Date.toString();
                        resultItem.UpdateBy = item.Update_By;
                        resultItem.UpdateDate = item.Update_Date.toString();
                        resultItem.CancelBy = item.Cancel_By;
                        resultItem.CancelDate = item.Cancel_Date.toString();
                        result.Add(resultItem);
                    }

                    return result;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }


        public String RunWave(ClickRunWaveViewModel model)
        {
            try
            {
                using (var context = new GIDbContext())
                {

                    String SqlPlanIN = "'x'";

                    foreach (var item in model.planGoodsIssueIndex)
                    {
                        SqlPlanIN += "," + item + "";
                    }


                    String SqlPlanGIwhere = " AND Convert(Nvarchar(200) , im_PlanGoodsIssue.PlanGoodsIssue_Index )  IN (" + SqlPlanIN + ")";
                    var strwhere = new SqlParameter("@strwhere", SqlPlanGIwhere);
                    var planGIResult = context.View_PLANWAVE.FromSql("sp_GetPLANWAVE @strwhere ", strwhere).ToList();




                    String SqlWaveTemplatewhere = " and  Convert(Nvarchar(200) ,Wave_Index ) = '" + "1A54883F-8619-4800-A46C-6E36DF478321" + "'" ;
                    var waveTemplatewhere = new SqlParameter("@strwhere", SqlWaveTemplatewhere);
                    var waveTemplateResult = context.View_PLANWAVE.FromSql("sp_GetViewWaveTemplate @strwhere ", waveTemplatewhere).ToList();



                    //  TODO
                    //GET Condition  From  RuleCondition Source 
                    //sp_GetViewWaveTemplate
                    //-----


                    //-----


                    //  TODO
                    //GET Condition  From  RuleCondition Destination
                    //sp_GetViewWaveTemplate
                    //-----

                    //-----

                    String SqlWhere = "";

                    // Set GUID for Wave
                    var IsUse = new SqlParameter("@IsUse", Guid.NewGuid().ToString());

                    var ListBinCardReserve = new List<BinCardReserveModel>();

                    //Prepare GI
                    var GoodsIssue = new GoodsIssueModel();
                    var ListGoodsIssueItem = new List<GoodsIssueItemModel>();
                    var ListGoodsIssueItemLocation = new List<GoodsIssueItemLocationModel>();

                    // GET NO .
                    var DocumentType_Index = new SqlParameter("@DocumentType_Index", "FB582EB6-EB57-412E-9640-90C0C659576D");

                    var DocDate = new SqlParameter("@DocDate", DateTime.Now);

                    var resultParameter = new SqlParameter("@txtReturn", SqlDbType.NVarChar);
                    resultParameter.Size = 2000; // some meaningfull value
                    resultParameter.Direction = ParameterDirection.Output;
                    context.Database.ExecuteSqlCommand("EXEC sp_Gen_DocumentNumber @DocumentType_Index , @DocDate ,@txtReturn OUTPUT", DocumentType_Index, DocDate, resultParameter);
                    //var result = resultParameter.Value;
                   String DocNum = resultParameter.Value.ToString();

                    Guid GI_Index  = Guid.NewGuid();
                    // LOOP Group SUM PLAN GI
                    foreach (var item in planGIResult)
                    {
                        SqlWhere = "";
                        //GET Condition  From Plan GI
                        if (item.Product_Index.ToString() != "")
                        {
                            SqlWhere += " And Convert(Nvarchar(200) , Product_Index ) = '" + item.Product_Index.ToString() + "' ";
                        }

                        if (item.Product_Lot.ToString() != "")
                        {
                            SqlWhere += " And Product_Lot = '" + item.Product_Lot.ToString() + "' ";
                        }

                        if (item.ItemStatus_Index.ToString() != "")
                        {
                            SqlWhere += " And Convert(Nvarchar(200) ,ItemStatus_Index) =  '" + item.ItemStatus_Index.ToString() + "' ";
                        }
                        if (item.MFG_Date.ToString() != "")
                        {
                            // SqlWhere += " And MFG_Date = @MFG_Date ";
                        }

                        if (item.EXP_Date.ToString() != "")
                        {
                            //SqlWhere += " And EXP_Date = @EXP_Date ";
                        }



                        // GET  DETAIL PLAN GI
                        String SqlPlanGIwhere2 = " AND Convert(Nvarchar(200) , PlanGoodsIssue_Index )  IN (" + SqlPlanIN + ") " + SqlWhere;
                        var strwhere2 = new SqlParameter("@strwhere", SqlPlanGIwhere2);
                        var planGIWaveResult = context.View_PLANWAVEbyPLANGI.FromSql("sp_WAVEPlanGoodsIssue @strwhere ", strwhere2).ToList();


                        // SET GI HEADER 
                        String DocCurrentDate = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
                        DateTime oDate = Convert.ToDateTime(DocCurrentDate);

                        GoodsIssue.GoodsIssue_Index = GI_Index;
                        GoodsIssue.Owner_Index = planGIWaveResult[0].Owner_Index;
                        GoodsIssue.Owner_Id = planGIWaveResult[0].Owner_Id;
                        GoodsIssue.Owner_Name = planGIWaveResult[0].Owner_Name;
                        GoodsIssue.DocumentType_Index = planGIWaveResult[0].DocumentType_Index;
                        GoodsIssue.DocumentType_Id = planGIWaveResult[0].DocumentType_Id;
                        GoodsIssue.DocumentType_Name = planGIWaveResult[0].DocumentType_Name;
                        GoodsIssue.GoodsIssue_No = DocNum;
                        GoodsIssue.GoodsIssue_Date = oDate;
                        GoodsIssue.DocumentRef_No1 = planGIWaveResult[0].DocumentRef_No1;
                        GoodsIssue.DocumentRef_No2 = planGIWaveResult[0].DocumentRef_No2;
                        GoodsIssue.DocumentRef_No3 = planGIWaveResult[0].DocumentRef_No3;
                        GoodsIssue.DocumentRef_No4 = planGIWaveResult[0].DocumentRef_No4;
                        GoodsIssue.DocumentRef_No5 = planGIWaveResult[0].DocumentRef_No5;
                        GoodsIssue.Document_Remark = planGIWaveResult[0].Document_Remark;
                        GoodsIssue.Document_Status = 0;
                        GoodsIssue.UDF_1 = planGIWaveResult[0].UDF_1;
                        GoodsIssue.UDF_2 = planGIWaveResult[0].UDF_2;
                        GoodsIssue.UDF_3 = planGIWaveResult[0].UDF_3;
                        GoodsIssue.UDF_4 = planGIWaveResult[0].UDF_4;
                        GoodsIssue.UDF_5 = planGIWaveResult[0].UDF_5;
                        GoodsIssue.DocumentPriority_Status = 1;
                        GoodsIssue.Picking_Status = 0;
                        GoodsIssue.Create_By = "Admin";
                      //  GoodsIssue.Create_Date = planGIWaveResult[0].Create_Date;
                        //GoodsIssue.Update_By = planGIWaveResult[0].                       ;
                        //GoodsIssue.Update_Date = planGIWaveResult[0].                                       ;
                        //GoodsIssue.Cancel_By = planGIWaveResult[0].                                         ;
                        //GoodsIssue.Cancel_Date = planGIWaveResult[0].                                       ;
                        //GoodsIssue.Warehouse_Index = planGIWaveResult[0].                                   ;
                        //GoodsIssue.Warehouse_Id = planGIWaveResult[0].                                      ;
                        //GoodsIssue.Warehouse_Name = planGIWaveResult[0].                                    ;




                        // Open Transaction
                        var transaction = context.Database.BeginTransaction(IsolationLevel.Serializable);


                        // Assign Qty for  wave Loop
                        var planQtyWave = item.QtyWave;
                        decimal? QtyRemian = item.QtyWave;

                        // Lock STOCK Balance 
                        String SqlcmdUpd = " Update [dbo].[wm_BinBalance] Set  IsUse =  @IsUse  where  isnull(IsUse,'') = ''  " + SqlWhere;
                        context.Database.ExecuteSqlCommand(SqlcmdUpd, IsUse);


                        // Get STOCK Balance 
                        String SqlOrderBycmd = " Order by GoodsReceive_Date ";
                        String Sqlcmd = " Select * from wm_BinBalance  Where IsUse = @IsUse" + SqlWhere + SqlOrderBycmd;
                        var BinBalanceResult = context.WM_BinBalance.FromSql(Sqlcmd, IsUse).ToList();

                      
                         

                        Boolean BreakLoopQtyBal = false;
                        foreach (var itemBin in BinBalanceResult)
                        {
                            decimal? QtyBal = itemBin.BinBalance_QtyBal - itemBin.BinBalance_QtyReserve;
                            decimal? QtyPlanGIRemian = 0;

                            if (BreakLoopQtyBal == true)
                            {
                                break; 
                            }
                            foreach (var itemPlanGI in planGIWaveResult)
                            {

                                QtyPlanGIRemian = itemPlanGI.TotalQty - itemPlanGI.GITotalQty ;

                                var BinCardReserve = new BinCardReserveModel();
                                var GoodsIssueItemLocation = new GoodsIssueItemLocationModel();
                                var GoodsIssueItem = new GoodsIssueItemModel();
                                if (QtyPlanGIRemian >= QtyBal)
                                {

                                    //Add GI ITEM
                                    GoodsIssueItem.GoodsIssueItem_Index = Guid.NewGuid();
                                    GoodsIssueItem.GoodsIssue_Index = GoodsIssue.GoodsIssue_Index;
                                    GoodsIssueItem.Product_Index = itemBin.Product_Index;
                                    GoodsIssueItem.Product_Id = itemBin.Product_Id;
                                    GoodsIssueItem.Product_Name = itemBin.Product_Name;
                                    GoodsIssueItem.Product_SecondName = itemBin.Product_SecondName;
                                    GoodsIssueItem.Product_ThirdName = itemBin.Product_ThirdName;
                                    GoodsIssueItem.Product_Lot = itemBin.Product_Lot;
                                    GoodsIssueItem.ItemStatus_Index = itemBin.ItemStatus_Index;
                                    GoodsIssueItem.ItemStatus_Id = itemBin.ItemStatus_Id;
                                    GoodsIssueItem.ItemStatus_Name = itemBin.ItemStatus_Name;
                                    GoodsIssueItem.QtyPlan = itemPlanGI.Qty;
                                    GoodsIssueItem.Qty = (Decimal)itemBin.BinBalance_QtyBal * (Decimal)itemPlanGI.Ratio;
                                    GoodsIssueItem.Ratio = (Decimal)itemPlanGI.Ratio;
                                    GoodsIssueItem.TotalQty = (Decimal)itemBin.BinBalance_QtyBal;
                                    GoodsIssueItem.ProductConversion_Index = (Guid)itemBin.ProductConversion_Index;
                                    GoodsIssueItem.ProductConversion_Id = itemBin.ProductConversion_Id;
                                    GoodsIssueItem.ProductConversion_Name = itemBin.ProductConversion_Name;
                                    GoodsIssueItem.MFG_Date = itemBin.GoodsReceive_MFG_Date;
                                    GoodsIssueItem.EXP_Date = itemBin.GoodsReceive_EXP_Date;
                                    //GoodsIssueItem.UnitWeight = itemBin.UnitWeight;
                                    GoodsIssueItem.Weight = (Decimal)itemBin.BinBalance_WeightBal;
                                    // GoodsIssueItem.UnitWidth = itemBin.UnitWidth;
                                    // GoodsIssueItem.UnitLength = itemBin.UnitLength;
                                    // GoodsIssueItem.UnitHeight = itemBin.UnitHeight;
                                    // GoodsIssueItem.UnitVolume = itemBin.UnitVolume;
                                    GoodsIssueItem.Volume = (Decimal)itemBin.BinBalance_VolumeBal;
                                    //GoodsIssueItem.UnitPrice = itemBin.UnitPrice;
                                    // GoodsIssueItem.Price = itemBin.Price;
                                    GoodsIssueItem.DocumentRef_No1 = itemPlanGI.DocumentRef_No1;
                                    GoodsIssueItem.DocumentRef_No2 = itemPlanGI.DocumentRef_No2;
                                    GoodsIssueItem.DocumentRef_No3 = itemPlanGI.DocumentRef_No3;
                                    GoodsIssueItem.DocumentRef_No4 = itemPlanGI.DocumentRef_No4;
                                    GoodsIssueItem.DocumentRef_No5 = itemPlanGI.DocumentRef_No5;
                                    GoodsIssueItem.Document_Status = itemPlanGI.Document_Status;
                                    GoodsIssueItem.UDF_1 = itemPlanGI.UDF_1;
                                    GoodsIssueItem.UDF_2 = itemPlanGI.UDF_2;
                                    GoodsIssueItem.UDF_3 = itemPlanGI.UDF_3;
                                    GoodsIssueItem.UDF_4 = itemPlanGI.UDF_4;
                                    GoodsIssueItem.UDF_5 = itemPlanGI.UDF_5;
                                    GoodsIssueItem.Ref_Process_Index = new Guid("22744590-55D8-4448-88EF-5997C252111F");  // PLAN GI Process
                                    GoodsIssueItem.Ref_Document_No = itemPlanGI.PlanGoodsIssue_No;
                                    //GoodsIssueItem.Ref_Document_LineNum = itemBin.Ref_Document_LineNum;
                                    GoodsIssueItem.Ref_Document_Index = (Guid)itemPlanGI.PlanGoodsIssue_Index;
                                    GoodsIssueItem.Ref_DocumentItem_Index = itemPlanGI.PlanGoodsIssueItem_Index;
                                    GoodsIssueItem.GoodsReceiveItem_Index = itemBin.GoodsReceiveItem_Index;
                                    GoodsIssueItem.Create_By = "admin";
                                    // GoodsIssueItem.Create_Date = DateTime.Now;
                                    //GoodsIssueItem.Update_By = itemBin.Update_By;
                                    //GoodsIssueItem.Update_Date = itemBin.Update_Date;
                                    //GoodsIssueItem.Cancel_By = itemBin.Cancel_By;
                                    //GoodsIssueItem.Cancel_Date = itemBin.Cancel_Date;

                                    ListGoodsIssueItem.Add(GoodsIssueItem);

                                    // Add GI ITEMLOCATION 
                                    GoodsIssueItemLocation.GoodsIssueItemLocation_Index = Guid.NewGuid();
                                    GoodsIssueItemLocation.GoodsIssueItem_Index = GoodsIssueItem.GoodsIssueItem_Index;
                                    GoodsIssueItemLocation.GoodsIssue_Index = GoodsIssue.GoodsIssue_Index;
                                    GoodsIssueItemLocation.TagItem_Index = itemBin.TagItem_Index;
                                    GoodsIssueItemLocation.Tag_Index = itemBin.Tag_Index;
                                    GoodsIssueItemLocation.Tag_No = itemBin.Tag_No;
                                    GoodsIssueItemLocation.Product_Index = itemBin.Product_Index;
                                    GoodsIssueItemLocation.Product_Id = itemBin.Product_Id;
                                    GoodsIssueItemLocation.Product_Name = itemBin.Product_Name;
                                    GoodsIssueItemLocation.Product_SecondName = itemBin.Product_SecondName;
                                    GoodsIssueItemLocation.Product_ThirdName = itemBin.Product_ThirdName;
                                    GoodsIssueItemLocation.Product_Lot = itemBin.Product_Lot;
                                    GoodsIssueItemLocation.ItemStatus_Index = itemBin.ItemStatus_Index;
                                    GoodsIssueItemLocation.ItemStatus_Id = itemBin.ItemStatus_Id;
                                    GoodsIssueItemLocation.ItemStatus_Name = itemBin.ItemStatus_Name;
                                    GoodsIssueItemLocation.Location_Index = itemBin.Location_Index;
                                    GoodsIssueItemLocation.Location_Id = itemBin.Location_Id;
                                    GoodsIssueItemLocation.Location_Name = itemBin.Location_Name;
                                    GoodsIssueItemLocation.Qty = (Decimal)itemBin.BinBalance_QtyBal * (Decimal)itemPlanGI.Ratio;
                                    GoodsIssueItemLocation.Ratio = (Decimal)itemPlanGI.Ratio;
                                    GoodsIssueItemLocation.TotalQty = (Decimal)itemBin.BinBalance_QtyBal;
                                    GoodsIssueItemLocation.ProductConversion_Index = (Guid)itemBin.ProductConversion_Index;
                                    GoodsIssueItemLocation.ProductConversion_Id = itemBin.ProductConversion_Id;
                                    GoodsIssueItemLocation.ProductConversion_Name = itemBin.ProductConversion_Name;
                                    GoodsIssueItemLocation.MFG_Date = itemBin.GoodsReceive_MFG_Date;
                                    GoodsIssueItemLocation.EXP_Date = itemBin.GoodsReceive_EXP_Date;
                                    //GoodsIssueItemLocation.UnitWeight = itemBin.UnitWeight;
                                    GoodsIssueItemLocation.Weight = (Decimal)itemBin.BinBalance_WeightBal;
                                    // GoodsIssueItemLocation.UnitWidth = itemBin.UnitWidth;
                                    // GoodsIssueItemLocation.UnitLength = itemBin.UnitLength;
                                    // GoodsIssueItemLocation.UnitHeight = itemBin.UnitHeight;
                                    // GoodsIssueItemLocation.UnitVolume = itemBin.UnitVolume;
                                    GoodsIssueItemLocation.Volume = (Decimal)itemBin.BinBalance_VolumeBal;
                                    //GoodsIssueItemLocation.UnitPrice = itemBin.UnitPrice;
                                    // GoodsIssueItemLocation.Price = itemBin.Price;
                                    GoodsIssueItemLocation.DocumentRef_No1 = itemPlanGI.DocumentRef_No1;
                                    GoodsIssueItemLocation.DocumentRef_No2 = itemPlanGI.DocumentRef_No2;
                                    GoodsIssueItemLocation.DocumentRef_No3 = itemPlanGI.DocumentRef_No3;
                                    GoodsIssueItemLocation.DocumentRef_No4 = itemPlanGI.DocumentRef_No4;
                                    GoodsIssueItemLocation.DocumentRef_No5 = itemPlanGI.DocumentRef_No5;
                                    GoodsIssueItemLocation.Document_Status = itemPlanGI.Document_Status;
                                    GoodsIssueItemLocation.UDF_1 = itemPlanGI.UDF_1;
                                    GoodsIssueItemLocation.UDF_2 = itemPlanGI.UDF_2;
                                    GoodsIssueItemLocation.UDF_3 = itemPlanGI.UDF_3;
                                    GoodsIssueItemLocation.UDF_4 = itemPlanGI.UDF_4;
                                    GoodsIssueItemLocation.UDF_5 = itemPlanGI.UDF_5;
                                    GoodsIssueItemLocation.Ref_Process_Index = new Guid("22744590-55D8-4448-88EF-5997C252111F");  // PLAN GI Process
                                    GoodsIssueItemLocation.Ref_Document_No = itemPlanGI.PlanGoodsIssue_No;
                                    //    GoodsIssueItemLocation.Ref_Document_LineNum = itemPlanGI.                                              ;
                                    GoodsIssueItemLocation.Ref_Document_Index = (Guid)itemPlanGI.PlanGoodsIssue_Index;
                                    GoodsIssueItemLocation.Ref_DocumentItem_Index = itemPlanGI.PlanGoodsIssueItem_Index;
                                    GoodsIssueItemLocation.GoodsReceiveItem_Index = itemBin.GoodsReceiveItem_Index;
                                    GoodsIssueItemLocation.Create_By = itemBin.Create_By;
                                  //  GoodsIssueItemLocation.Create_Date = DateTime.Now;
                                    //GoodsIssueItemLocation.Update_By = itemBin.
                                    //GoodsIssueItemLocation.Update_Date = itemBin.
                                    //GoodsIssueItemLocation.Cancel_By = itemBin.
                                    //GoodsIssueItemLocation.Cancel_Date = itemBin.
                                    //GoodsIssueItemLocation.Picking_Status = itemBin.
                                    //GoodsIssueItemLocation.Picking_By = itemBin.
                                    //GoodsIssueItemLocation.Picking_Date = itemBin.
                                    //GoodsIssueItemLocation.Picking_Ref1 = itemBin.
                                    //GoodsIssueItemLocation.Picking_Ref2 = itemBin.
                                    //GoodsIssueItemLocation.Picking_Qty = itemBin.
                                    //GoodsIssueItemLocation.Picking_Ratio = itemBin.
                                    //GoodsIssueItemLocation.Picking_TotalQty = itemBin.
                                    //GoodsIssueItemLocation.Picking_ProductConversion_Index = itemBin.
                                    //GoodsIssueItemLocation.Mashall_Status = itemBin.
                                    //GoodsIssueItemLocation.Mashall_Qty = itemBin.

                                    ListGoodsIssueItemLocation.Add(GoodsIssueItemLocation);


                                    // Add BinCardReserve
                                    BinCardReserve.BinCardReserve_Index = Guid.NewGuid();
                                    BinCardReserve.BinBalance_Index = itemBin.BinBalance_Index;
                                    BinCardReserve.Process_Index = new Guid("19CCA9B3-B4D2-4BC5-87F7-DE64C1E75CBF");  // GI Process
                                    BinCardReserve.GoodsReceive_Index = itemBin.GoodsReceive_Index;
                                    BinCardReserve.GoodsReceive_No = itemBin.GoodsReceive_No;
                                    BinCardReserve.GoodsReceive_Date = itemBin.GoodsReceive_Date;
                                    BinCardReserve.GoodsReceiveItem_Index = itemBin.GoodsReceiveItem_Index;
                                    BinCardReserve.TagItem_Index = itemBin.TagItem_Index;
                                    BinCardReserve.Tag_Index = itemBin.Tag_Index;
                                    BinCardReserve.Tag_No = itemBin.Tag_No;
                                    BinCardReserve.Product_Index = itemBin.Product_Index;
                                    BinCardReserve.Product_Id = itemBin.Product_Id;
                                    BinCardReserve.Product_Name = itemBin.Product_Name;
                                    BinCardReserve.Product_SecondName = itemBin.Product_SecondName;
                                    BinCardReserve.Product_ThirdName = itemBin.Product_ThirdName;
                                    BinCardReserve.Product_Lot = itemBin.Product_Lot;
                                    BinCardReserve.ItemStatus_Index = itemBin.ItemStatus_Index;
                                    BinCardReserve.ItemStatus_Id = itemBin.ItemStatus_Id;
                                    BinCardReserve.ItemStatus_Name = itemBin.ItemStatus_Name;
                                    BinCardReserve.MFG_Date = itemBin.GoodsReceive_MFG_Date;
                                    BinCardReserve.EXP_Date = itemBin.GoodsReceive_EXP_Date;
                                    BinCardReserve.ProductConversion_Index = itemBin.ProductConversion_Index;
                                    BinCardReserve.ProductConversion_Id = itemBin.ProductConversion_Id;
                                    BinCardReserve.ProductConversion_Name = itemBin.ProductConversion_Name;
                                    BinCardReserve.Owner_Index = itemBin.Owner_Index;
                                    BinCardReserve.Owner_Id = itemBin.Owner_Id;
                                    BinCardReserve.Owner_Name = itemBin.Owner_Name;
                                    BinCardReserve.Location_Index = itemBin.Location_Index;
                                    BinCardReserve.Location_Id = itemBin.Location_Id;
                                    BinCardReserve.Location_Name = itemBin.Location_Name;
                                    BinCardReserve.BinCardReserve_QtyBal = itemBin.BinBalance_QtyBal;
                                    BinCardReserve.BinCardReserve_WeightBal = itemBin.BinBalance_WeightBal;
                                    BinCardReserve.BinCardReserve_VolumeBal = itemBin.BinBalance_VolumeBal;
                                    //  BinCardReserve.Ref_Document_No = ""  ;
                                    //   BinCardReserve.Ref_Document_Index = "";
                                    //  BinCardReserve.Ref_DocumentItem_Index = itemBin.                                             ;
                                    BinCardReserve.Ref_Wave_Index = IsUse.ToString();
                                    BinCardReserve.Create_By = "admin";
                                  //  BinCardReserve.Create_Date = DateTime.Now;

                                    ListBinCardReserve.Add(BinCardReserve);

                                    itemPlanGI.GITotalQty = itemPlanGI.GITotalQty + QtyBal;

                                    QtyPlanGIRemian = QtyPlanGIRemian - QtyBal;




                                    // Update QtyReserve In BinCardReserve

                                    //var BinBalance_QtyReserve = new SqlParameter("@BinBalance_QtyReserve", itemBin.BinBalance_QtyBal);
                                    //var BinBalance_WeightReserve = new SqlParameter("@BinBalance_WeightReserve", itemBin.BinBalance_WeightBal);
                                    //var BinBalance_VolumeReserve = new SqlParameter("@BinBalance_VolumeReserve", itemBin.BinBalance_VolumeBal);
                                    //var BinBalance_Index = new SqlParameter("@BinBalance_Index", itemBin.BinBalance_Index);
                                    //String SqlcmdUpdReserve = " Update [dbo].[wm_BinBalance]  SET " +
                                    //                         "     BinBalance_QtyReserve  =  @BinBalance_QtyReserve " +
                                    //                         "  BinBalance_WeightReserve  =  @BinBalance_WeightReserve " +
                                    //                         "  BinBalance_VolumeReserve  =  @BinBalance_VolumeReserve " +
                                    //                         "  where  BinBalance_Index = @BinBalance_Index  " + SqlWhere;
                                    //context.Database.ExecuteSqlCommand(SqlcmdUpdReserve, BinBalance_QtyReserve, BinBalance_WeightReserve, BinBalance_VolumeReserve, BinBalance_Index);






                                }
                                else if (QtyPlanGIRemian < QtyBal && QtyPlanGIRemian > 0)
                                {
                                    var QtyPick = QtyPlanGIRemian;

                                    //Add GI ITEM
                                    GoodsIssueItem.GoodsIssueItem_Index = Guid.NewGuid();
                                    GoodsIssueItem.GoodsIssue_Index = GoodsIssue.GoodsIssue_Index;
                                    GoodsIssueItem.Product_Index = itemBin.Product_Index;
                                    GoodsIssueItem.Product_Id = itemBin.Product_Id;
                                    GoodsIssueItem.Product_Name = itemBin.Product_Name;
                                    GoodsIssueItem.Product_SecondName = itemBin.Product_SecondName;
                                    GoodsIssueItem.Product_ThirdName = itemBin.Product_ThirdName;
                                    GoodsIssueItem.Product_Lot = itemBin.Product_Lot;
                                    GoodsIssueItem.ItemStatus_Index = itemBin.ItemStatus_Index;
                                    GoodsIssueItem.ItemStatus_Id = itemBin.ItemStatus_Id;
                                    GoodsIssueItem.ItemStatus_Name = itemBin.ItemStatus_Name;
                                    GoodsIssueItem.QtyPlan = itemPlanGI.Qty;
                                    GoodsIssueItem.Qty = (Decimal)itemBin.BinBalance_QtyBal * (Decimal)itemPlanGI.Ratio;
                                    GoodsIssueItem.Ratio = (Decimal)itemPlanGI.Ratio;
                                    GoodsIssueItem.TotalQty = (Decimal)itemBin.BinBalance_QtyBal;
                                    GoodsIssueItem.ProductConversion_Index = (Guid)itemBin.ProductConversion_Index;
                                    GoodsIssueItem.ProductConversion_Id = itemBin.ProductConversion_Id;
                                    GoodsIssueItem.ProductConversion_Name = itemBin.ProductConversion_Name;
                                    GoodsIssueItem.MFG_Date = itemBin.GoodsReceive_MFG_Date;
                                    GoodsIssueItem.EXP_Date = itemBin.GoodsReceive_EXP_Date;
                                    //GoodsIssueItem.UnitWeight = itemBin.UnitWeight;
                                    if (itemBin.BinBalance_WeightBegin == 0)
                                    {
                                        GoodsIssueItem.Weight = (Decimal)(QtyPick * (itemBin.BinBalance_QtyBegin / 1));
                                    }
                                    else
                                    {
                                        GoodsIssueItem.Weight = (Decimal)(QtyPick * (itemBin.BinBalance_QtyBegin / itemBin.BinBalance_WeightBegin));

                                    }

                                    // GoodsIssueItem.UnitWidth = itemBin.UnitWidth;
                                    // GoodsIssueItem.UnitLength = itemBin.UnitLength;
                                    // GoodsIssueItem.UnitHeight = itemBin.UnitHeight;
                                    // GoodsIssueItem.UnitVolume = itemBin.UnitVolume;
                                    if (itemBin.BinBalance_VolumeBegin == 0)
                                    {
                                        GoodsIssueItem.Volume = (Decimal)(QtyPick * (itemBin.BinBalance_QtyBegin / 1));
                                    }
                                    else
                                    {
                                        GoodsIssueItem.Volume = (Decimal)(QtyPick * (itemBin.BinBalance_QtyBegin / itemBin.BinBalance_VolumeBegin));

                                    }
                                    //GoodsIssueItem.UnitPrice = itemBin.UnitPrice;
                                    // GoodsIssueItem.Price = itemBin.Price;
                                    GoodsIssueItem.DocumentRef_No1 = itemPlanGI.DocumentRef_No1;
                                    GoodsIssueItem.DocumentRef_No2 = itemPlanGI.DocumentRef_No2;
                                    GoodsIssueItem.DocumentRef_No3 = itemPlanGI.DocumentRef_No3;
                                    GoodsIssueItem.DocumentRef_No4 = itemPlanGI.DocumentRef_No4;
                                    GoodsIssueItem.DocumentRef_No5 = itemPlanGI.DocumentRef_No5;
                                    GoodsIssueItem.Document_Status = itemPlanGI.Document_Status;
                                    GoodsIssueItem.UDF_1 = itemPlanGI.UDF_1;
                                    GoodsIssueItem.UDF_2 = itemPlanGI.UDF_2;
                                    GoodsIssueItem.UDF_3 = itemPlanGI.UDF_3;
                                    GoodsIssueItem.UDF_4 = itemPlanGI.UDF_4;
                                    GoodsIssueItem.UDF_5 = itemPlanGI.UDF_5;
                                    GoodsIssueItem.Ref_Process_Index = new Guid("22744590-55D8-4448-88EF-5997C252111F");  // PLAN GI Process
                                    GoodsIssueItem.Ref_Document_No = itemPlanGI.PlanGoodsIssue_No;
                                    //GoodsIssueItem.Ref_Document_LineNum = itemBin.Ref_Document_LineNum;
                                    GoodsIssueItem.Ref_Document_Index = (Guid)itemPlanGI.PlanGoodsIssue_Index;
                                    GoodsIssueItem.Ref_DocumentItem_Index = itemPlanGI.PlanGoodsIssueItem_Index;
                                    GoodsIssueItem.GoodsReceiveItem_Index = itemBin.GoodsReceiveItem_Index;
                                    GoodsIssueItem.Create_By = "admin";
                                    //     GoodsIssueItem.Create_Date = DateTime.Now;
                                    //GoodsIssueItem.Update_By = itemBin.Update_By;
                                    //GoodsIssueItem.Update_Date = itemBin.Update_Date;
                                    //GoodsIssueItem.Cancel_By = itemBin.Cancel_By;
                                    //GoodsIssueItem.Cancel_Date = itemBin.Cancel_Date;

                                    ListGoodsIssueItem.Add(GoodsIssueItem);


                                    // Add GI ITEMLOCATION 
                                    GoodsIssueItemLocation.GoodsIssueItemLocation_Index = Guid.NewGuid();
                                    GoodsIssueItemLocation.GoodsIssueItem_Index = GoodsIssueItem.GoodsIssueItem_Index;
                                    GoodsIssueItemLocation.GoodsIssue_Index = GoodsIssue.GoodsIssue_Index;
                                    GoodsIssueItemLocation.TagItem_Index = itemBin.TagItem_Index;
                                    GoodsIssueItemLocation.Tag_Index = itemBin.Tag_Index;
                                    GoodsIssueItemLocation.Tag_No = itemBin.Tag_No;
                                    GoodsIssueItemLocation.Product_Index = itemBin.Product_Index;
                                    GoodsIssueItemLocation.Product_Id = itemBin.Product_Id;
                                    GoodsIssueItemLocation.Product_Name = itemBin.Product_Name;
                                    GoodsIssueItemLocation.Product_SecondName = itemBin.Product_SecondName;
                                    GoodsIssueItemLocation.Product_ThirdName = itemBin.Product_ThirdName;
                                    GoodsIssueItemLocation.Product_Lot = itemBin.Product_Lot;
                                    GoodsIssueItemLocation.ItemStatus_Index = itemBin.ItemStatus_Index;
                                    GoodsIssueItemLocation.ItemStatus_Id = itemBin.ItemStatus_Id;
                                    GoodsIssueItemLocation.ItemStatus_Name = itemBin.ItemStatus_Name;
                                    GoodsIssueItemLocation.Location_Index = itemBin.Location_Index;
                                    GoodsIssueItemLocation.Location_Id = itemBin.Location_Id;
                                    GoodsIssueItemLocation.Location_Name = itemBin.Location_Name;
                                    GoodsIssueItemLocation.Qty = (Decimal)QtyPick * (Decimal)itemPlanGI.Ratio;
                                    GoodsIssueItemLocation.Ratio = (Decimal)itemPlanGI.Ratio;
                                    GoodsIssueItemLocation.TotalQty = (Decimal)QtyPick;
                                    GoodsIssueItemLocation.ProductConversion_Index = (Guid)itemBin.ProductConversion_Index;
                                    GoodsIssueItemLocation.ProductConversion_Id = itemBin.ProductConversion_Id;
                                    GoodsIssueItemLocation.ProductConversion_Name = itemBin.ProductConversion_Name;
                                    GoodsIssueItemLocation.MFG_Date = itemBin.GoodsReceive_MFG_Date;
                                    GoodsIssueItemLocation.EXP_Date = itemBin.GoodsReceive_EXP_Date;
                                    //GoodsIssueItemLocation.UnitWeight = itemBin.UnitWeight;
                                  
                                    if (itemBin.BinBalance_WeightBegin == 0)
                                    {
                                        GoodsIssueItemLocation.Weight = (Decimal)(QtyPick * (itemBin.BinBalance_QtyBegin / 1));
                                    }
                                    else
                                    {
                                        GoodsIssueItemLocation.Weight = (Decimal)(QtyPick * (itemBin.BinBalance_QtyBegin / itemBin.BinBalance_WeightBegin));

                                    }

                                    // GoodsIssueItemLocation.UnitWidth = itemBin.UnitWidth;
                                    // GoodsIssueItemLocation.UnitLength = itemBin.UnitLength;
                                    // GoodsIssueItemLocation.UnitHeight = itemBin.UnitHeight;
                                    // GoodsIssueItemLocation.UnitVolume = itemBin.UnitVolume;
                            
                                    if (itemBin.BinBalance_VolumeBegin == 0)
                                    {
                                        GoodsIssueItemLocation.Volume = (Decimal)(QtyPick * (itemBin.BinBalance_QtyBegin / 1));
                                    }
                                    else
                                    {
                                        GoodsIssueItemLocation.Volume = (Decimal)(QtyPick * (itemBin.BinBalance_QtyBegin / itemBin.BinBalance_VolumeBegin));

                                    }
                                    //GoodsIssueItemLocation.UnitPrice = itemBin.UnitPrice;
                                    // GoodsIssueItemLocation.Price = itemBin.Price;
                                    GoodsIssueItemLocation.DocumentRef_No1 = itemPlanGI.DocumentRef_No1;
                                    GoodsIssueItemLocation.DocumentRef_No2 = itemPlanGI.DocumentRef_No2;
                                    GoodsIssueItemLocation.DocumentRef_No3 = itemPlanGI.DocumentRef_No3;
                                    GoodsIssueItemLocation.DocumentRef_No4 = itemPlanGI.DocumentRef_No4;
                                    GoodsIssueItemLocation.DocumentRef_No5 = itemPlanGI.DocumentRef_No5;
                                    GoodsIssueItemLocation.Document_Status = itemPlanGI.Document_Status;
                                    GoodsIssueItemLocation.UDF_1 = itemPlanGI.UDF_1;
                                    GoodsIssueItemLocation.UDF_2 = itemPlanGI.UDF_2;
                                    GoodsIssueItemLocation.UDF_3 = itemPlanGI.UDF_3;
                                    GoodsIssueItemLocation.UDF_4 = itemPlanGI.UDF_4;
                                    GoodsIssueItemLocation.UDF_5 = itemPlanGI.UDF_5;
                                    GoodsIssueItemLocation.Ref_Process_Index = new Guid("22744590-55D8-4448-88EF-5997C252111F");  // PLAN GI Process
                                    GoodsIssueItemLocation.Ref_Document_No = itemPlanGI.PlanGoodsIssue_No;
                                    //    GoodsIssueItemLocation.Ref_Document_LineNum = itemPlanGI.                                              ;
                                    GoodsIssueItemLocation.Ref_Document_Index = (Guid)itemPlanGI.PlanGoodsIssue_Index;
                                    GoodsIssueItemLocation.Ref_DocumentItem_Index = itemPlanGI.PlanGoodsIssueItem_Index;
                                    GoodsIssueItemLocation.GoodsReceiveItem_Index = itemBin.GoodsReceiveItem_Index;
                                    GoodsIssueItemLocation.Create_By = itemBin.Create_By;
                                   // GoodsIssueItemLocation.Create_Date = DateTime.Now;
                                    //GoodsIssueItemLocation.Update_By = itemBin.
                                    //GoodsIssueItemLocation.Update_Date = itemBin.
                                    //GoodsIssueItemLocation.Cancel_By = itemBin.
                                    //GoodsIssueItemLocation.Cancel_Date = itemBin.
                                    //GoodsIssueItemLocation.Picking_Status = itemBin.
                                    //GoodsIssueItemLocation.Picking_By = itemBin.
                                    //GoodsIssueItemLocation.Picking_Date = itemBin.
                                    //GoodsIssueItemLocation.Picking_Ref1 = itemBin.
                                    //GoodsIssueItemLocation.Picking_Ref2 = itemBin.
                                    //GoodsIssueItemLocation.Picking_Qty = itemBin.
                                    //GoodsIssueItemLocation.Picking_Ratio = itemBin.
                                    //GoodsIssueItemLocation.Picking_TotalQty = itemBin.
                                    //GoodsIssueItemLocation.Picking_ProductConversion_Index = itemBin.
                                    //GoodsIssueItemLocation.Mashall_Status = itemBin.
                                    //GoodsIssueItemLocation.Mashall_Qty = itemBin.

                                    ListGoodsIssueItemLocation.Add(GoodsIssueItemLocation);


                                    // ADD Bin Reserve
                                    BinCardReserve.BinCardReserve_Index = Guid.NewGuid();
                                    BinCardReserve.BinBalance_Index = itemBin.BinBalance_Index;
                                    BinCardReserve.Process_Index = new Guid("19CCA9B3-B4D2-4BC5-87F7-DE64C1E75CBF");  // GI Process
                                    BinCardReserve.GoodsReceive_Index = itemBin.GoodsReceive_Index;
                                    BinCardReserve.GoodsReceive_No = itemBin.GoodsReceive_No;
                                    BinCardReserve.GoodsReceive_Date = itemBin.GoodsReceive_Date;
                                    BinCardReserve.GoodsReceiveItem_Index = itemBin.GoodsReceiveItem_Index;
                                    BinCardReserve.TagItem_Index = itemBin.TagItem_Index;
                                    BinCardReserve.Tag_Index = itemBin.Tag_Index;
                                    BinCardReserve.Tag_No = itemBin.Tag_No;
                                    BinCardReserve.Product_Index = itemBin.Product_Index;
                                    BinCardReserve.Product_Id = itemBin.Product_Id;
                                    BinCardReserve.Product_Name = itemBin.Product_Name;
                                    BinCardReserve.Product_SecondName = itemBin.Product_SecondName;
                                    BinCardReserve.Product_ThirdName = itemBin.Product_ThirdName;
                                    BinCardReserve.Product_Lot = itemBin.Product_Lot;
                                    BinCardReserve.ItemStatus_Index = itemBin.ItemStatus_Index;
                                    BinCardReserve.ItemStatus_Id = itemBin.ItemStatus_Id;
                                    BinCardReserve.ItemStatus_Name = itemBin.ItemStatus_Name;
                                    BinCardReserve.MFG_Date = itemBin.GoodsReceive_MFG_Date;
                                    BinCardReserve.EXP_Date = itemBin.GoodsReceive_EXP_Date;
                                    BinCardReserve.ProductConversion_Index = itemBin.ProductConversion_Index;
                                    BinCardReserve.ProductConversion_Id = itemBin.ProductConversion_Id;
                                    BinCardReserve.ProductConversion_Name = itemBin.ProductConversion_Name;
                                    BinCardReserve.Owner_Index = itemBin.Owner_Index;
                                    BinCardReserve.Owner_Id = itemBin.Owner_Id;
                                    BinCardReserve.Owner_Name = itemBin.Owner_Name;
                                    BinCardReserve.Location_Index = itemBin.Location_Index;
                                    BinCardReserve.Location_Id = itemBin.Location_Id;
                                    BinCardReserve.Location_Name = itemBin.Location_Name;
                                    BinCardReserve.BinCardReserve_QtyBal = QtyPick;
                                    if (itemBin.BinBalance_WeightBegin == 0)
                                    {
                                        BinCardReserve.BinCardReserve_WeightBal = QtyPick * (itemBin.BinBalance_QtyBegin / 1);
                                    }
                                    else
                                    {
                                        BinCardReserve.BinCardReserve_WeightBal = QtyPick * (itemBin.BinBalance_QtyBegin / itemBin.BinBalance_WeightBegin);

                                    }
                                    if (itemBin.BinBalance_VolumeBegin == 0)
                                    {
                                        BinCardReserve.BinCardReserve_VolumeBal = QtyPick * (itemBin.BinBalance_QtyBegin / 1);
                                    }
                                    else
                                    {
                                        BinCardReserve.BinCardReserve_VolumeBal = QtyPick * (itemBin.BinBalance_QtyBegin / itemBin.BinBalance_VolumeBegin);

                                    }

                                    //   BinCardReserve.Ref_Document_No = ""  ;
                                    //  BinCardReserve.Ref_Document_Index = "";
                                    //  BinCardReserve.Ref_DocumentItem_Index = itemBin.                                             ;
                                    BinCardReserve.Ref_Wave_Index = IsUse.Value.ToString();
                                    BinCardReserve.Create_By = "admin";
                              //      BinCardReserve.Create_Date =  itemBin.Create_Date;

                                    ListBinCardReserve.Add(BinCardReserve);

                                    itemPlanGI.GITotalQty = itemPlanGI.GITotalQty + QtyPick;

                                    QtyPlanGIRemian = QtyPlanGIRemian - QtyPick;

                                    // Update QtyReserve In BinCardReserve

                                    //var BinBalance_QtyReserve = new SqlParameter("@BinBalance_QtyReserve", QtyPick);
                                    //var BinBalance_WeightReserve = new SqlParameter("@BinBalance_WeightReserve", QtyPick * (itemBin.BinBalance_QtyBegin / itemBin.BinBalance_WeightBegin));
                                    //var BinBalance_VolumeReserve = new SqlParameter("@BinBalance_VolumeReserve", QtyPick * (itemBin.BinBalance_QtyBegin / itemBin.BinBalance_VolumeBegin));
                                    //var BinBalance_Index = new SqlParameter("@BinBalance_Index", itemBin.BinBalance_Index);
                                    //String SqlcmdUpdReserve = " Update [dbo].[wm_BinBalance]  SET " +
                                    //                         "     BinBalance_QtyReserve  =  @BinBalance_QtyReserve " +
                                    //                         "  BinBalance_WeightReserve  =  @BinBalance_WeightReserve " +
                                    //                         "  BinBalance_VolumeReserve  =  @BinBalance_VolumeReserve " +
                                    //                         "  where  BinBalance_Index = @BinBalance_Index  " + SqlWhere;
                                    //context.Database.ExecuteSqlCommand(SqlcmdUpdReserve, BinBalance_QtyReserve, BinBalance_WeightReserve, BinBalance_VolumeReserve, BinBalance_Index);


                                }
                                else if (QtyPlanGIRemian == 0)// QtyRemian = 0 
                                {
                                    BreakLoopQtyBal = true;
                                    break;

                                }
                            }






                        }


                        transaction.Commit(); 

                    }  // END For Group SUM  PLAN GI



                    // Clear LOCK
                    String SqlcmdUpF = " Update [dbo].[wm_BinBalance] Set  IsUse = '' where  isnull(IsUse,'') = @IsUse";

                    context.Database.ExecuteSqlCommand(SqlcmdUpF, IsUse);


                    // INSERT BIN RESERVE AFTER WAVE
                    DataTable dtBinCardReserve = CreateDataTable(ListBinCardReserve);

                    var pBinCardReserve = new SqlParameter("BinCardReserve", SqlDbType.Structured);
                    pBinCardReserve.TypeName = "[dbo].[wm_BinCardReserveData]";
                    pBinCardReserve.Value = dtBinCardReserve;

                    var commandText = "EXEC sp_Save_BinCardReserve @BinCardReserve";
                    var rowsBinCardReserveAffected = context.Database.ExecuteSqlCommand(commandText, pBinCardReserve);

                    // INSERT GI AFTER WAVE
                    var listGoodsIssue = new List<GoodsIssueModel>();
                    listGoodsIssue.Add(GoodsIssue);
                    DataTable dtGoodsIssue = CreateDataTable(listGoodsIssue);
                    DataTable dtGoodsIssueItem = CreateDataTable(ListGoodsIssueItem);
                    DataTable dtGoodsIssueItemLocation = CreateDataTable(ListGoodsIssueItemLocation);

                    var pGoodsIssue = new SqlParameter("GoodsIssue", SqlDbType.Structured);
                    pGoodsIssue.TypeName = "[dbo].[im_GoodsIssueData]";
                    pGoodsIssue.Value = dtGoodsIssue;

                    var pGoodsIssueItem = new SqlParameter("GoodsIssueItem", SqlDbType.Structured);
                    pGoodsIssueItem.TypeName = "[dbo].[im_GoodsIssueItemData]";
                    pGoodsIssueItem.Value = dtGoodsIssueItem;

                    var pGoodsIssueItemLocation = new SqlParameter("GoodsIssueItemLocation", SqlDbType.Structured);
                    pGoodsIssueItemLocation.TypeName = "[dbo].[im_GoodsIssueItemLocationData]";
                    pGoodsIssueItemLocation.Value = dtGoodsIssueItemLocation;

                    var commandGIText = "EXEC sp_Save_im_GoodsIssue @GoodsIssue ,@GoodsIssueItem ,@GoodsIssueItemLocation ";
                    var rowsGoodsIssueAffected = context.Database.ExecuteSqlCommand(commandGIText, pGoodsIssue, pGoodsIssueItem, pGoodsIssueItemLocation);







                    if (dtBinCardReserve.Rows.Count > 0 && dtGoodsIssueItemLocation.Rows.Count > 0)
                    {
                        return "true ";
                    }

                    //Get Reserved
                    //String SqlcmdReserve = " Select * from wm_BinCardReserve  Where IsUse = @IsUse";

                    //var BinCardReserveResult = context.WM_BinCardReserve.FromSql(SqlcmdReserve, IsUse).ToList();

                    //if (BinCardReserveResult.Count < 1)
                    //{
                    //    // CLEAR RESERVE
                    //}
                    //DataTable dtBinCardReserveqty = CreateDataTable(BinCardReserveResult);
                    ////




                }  // END  WAVE PICK LOOP











                // GET DATA PLAN GI 

                //SqlWhere = "";

                //String SqlPlanGIwhere2 = " AND Convert(Nvarchar(200) , PlanGoodsIssue_Index )  IN (" + SqlPlanIN + ") ";// + SqlWhere;
                //var strwhere2 = new SqlParameter("@strwhere", SqlPlanGIwhere2);
                //var planGIWaveResult = context.View_PLANWAVE.FromSql("sp_WAVEPlanGoodsIssue @strwhere ", strwhere2).ToList();


                //foreach (var itemplanGI in planGIWaveResult)
                //{


                //    SqlWhere = "";
                //    if (itemplanGI.Product_Index.ToString() != "")
                //        {
                //            SqlWhere += " And Convert(Nvarchar(200) , Product_Index ) = '" + itemplanGI.Product_Index.ToString() + "' ";
                //        }

                //        if (itemplanGI.Product_Lot.ToString() != "")
                //        {
                //            SqlWhere += " And Product_Lot = '" + itemplanGI.Product_Lot.ToString() + "' ";
                //        }

                //        if (itemplanGI.ItemStatus_Index.ToString() != "")
                //        {
                //            SqlWhere += " And Convert(Nvarchar(200) ,ItemStatus_Index) =  '" + itemplanGI.ItemStatus_Index.ToString() + "' ";
                //        }

                //    //if (itemplanGI.MFG_Date.ToString() != "")
                //    //{
                //    //    // SqlWhere += " And MFG_Date = @MFG_Date ";
                //    //}

                //    //if (itemplanGI.EXP_Date.ToString() != "")
                //    //{
                //    //    //SqlWhere += " And EXP_Date = @EXP_Date ";
                //    //}
                //    DataRow[] result = dtBinCardReserveqty.Select(SqlWhere);
                //    foreach  (DataRow drr in result)
                //    {
                //        var QtyPlan = drr[""];
                //    }




                //}





                // 
                // sp_GetBinCardReserve


                //  context.Database.ExecuteSqlCommand(Sqlcmd);



                //  var Marshall = new MarshallModel();
                var ListMarshallItem = new List<MarshallItemModel>();
                // Set Header Mashall
                //Marshall.Marshall_Index = Guid.NewGuid();
                //Marshall.Owner_Index = item.Owner_Index;
                //Marshall.Owner_Id = item.Owner_Id;
                //Marshall.Owner_Name = item.Owner_Name;
                //Marshall.DocumentType_Index = item.DocumentType_Index;
                //Marshall.DocumentType_Id = item.DocumentType_Id;
                //Marshall.DocumentType_Name = item.DocumentType_Name;
                //Marshall.Marshall_No = item.Marshall_No;
                //Marshall.Marshall_Date = item.Marshall_Date;
                //Marshall.DocumentRef_No1 = item.DocumentRef_No1;
                //Marshall.DocumentRef_No2 = item.DocumentRef_No2;
                //Marshall.DocumentRef_No3 = item.DocumentRef_No3;
                //Marshall.DocumentRef_No4 = item.DocumentRef_No4;
                //Marshall.DocumentRef_No5 = item.DocumentRef_No5;
                //Marshall.Document_Status = item.Document_Status;
                //Marshall.Document_Remark = item.Document_Remark;
                //Marshall.UDF_1 = item.UDF_1;
                //Marshall.UDF_2 = item.UDF_2;
                //Marshall.UDF_3 = item.UDF_3;
                //Marshall.UDF_4 = item.UDF_4;
                //Marshall.UDF_5 = item.UDF_5;
                //Marshall.DocumentPriority_Status = item.DocumentPriority_Status;
                //Marshall.Create_By = item.Create_By;
                //Marshall.Create_Date = item.Create_Date;
                //Marshall.Update_By = item.Update_By;
                //Marshall.Update_Date = item.Update_Date;
                //Marshall.Cancel_By = item.Cancel_By;
                //Marshall.Cancel_Date = item.Cancel_Date;
                //Marshall.Putaway_Status = item.Putaway_Status;
                //Marshall.Warehouse_Index = item.Warehouse_Index;
                //Marshall.Warehouse_Id = item.Warehouse_Id;
                //Marshall.Warehouse_Name = item.Warehouse_Name;






                return "true";

            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
   
        public static DataTable CreateDataTable<T>(IEnumerable<T> list)
        {
            Type type = typeof(T);
            var properties = type.GetProperties();

            DataTable dataTable = new DataTable();
            foreach (PropertyInfo info in properties)
            {
                dataTable.Columns.Add(new DataColumn(info.Name, Nullable.GetUnderlyingType(info.PropertyType) ?? info.PropertyType));

            }

            foreach (T entity in list)
            {
                object[] values = new object[properties.Length];
                for (int i = 0; i < properties.Length; i++)
                {
                    values[i] = properties[i].GetValue(entity);
                }

                dataTable.Rows.Add(values);
            }

            return dataTable;
        }
    }
}
